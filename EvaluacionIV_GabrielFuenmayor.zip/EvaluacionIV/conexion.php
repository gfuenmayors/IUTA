<?php
class Conexion {
    public static function Conectar() {
        define('server', 'localhost');
        define('database', 'evaluacioniv');
        define('user', 'root');
        define('password', '');
        $opciones = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
        try {
            $conexion = new PDO("mysql:host=".server."; dbname=".database, user, password);
            return $conexion;
        }
        catch (exception $e) {
            die("Error: ". $e.getmessage());
        }
    }
}
?>