<?php
class Conexion {
    public static function Conectar() {
        define('server', 'sql213.epizy.com');
        define('database', 'epiz_29755692_evaluacioniv');
        define('user', 'epiz_29755692');
        define('password', '02Tg38HtQXf7sO');
        $opciones = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
        try {
            $conexion = new PDO("mysql:host=".server."; dbname=".database, user, password);
            return $conexion;
        }
        catch (exception $e) {
            die("Error: ". $e.getmessage());
        }
    }
}
?>