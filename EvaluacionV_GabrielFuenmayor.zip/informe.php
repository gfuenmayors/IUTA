<?php
    include_once 'conexion.php';
    require 'fpdf/fpdf.php';

    $con = new Conexion();
    $conexion = $con->Conectar();

    $sql = "SELECT * FROM usuarios";
    $result = $conexion->query($sql);

    $pdf = new FPDF("P", "mm", "letter");
    $pdf->AliasNbPages();
    $pdf->SetMargins(10, 10, 10);
    $pdf->AddPage();

    $pdf->SetFont("Arial", "B", 9);

    $pdf->Cell(10, 5, "ID", 1, 0, "C");
    $pdf->Cell(30, 5, "Usuario", 1, 0, "C");
    $pdf->Cell(30, 5, "Nombre", 1, 0, "C");
    $pdf->Cell(30, 5, "Apellido", 1, 0, "C");
    $pdf->Cell(30, 5, "Genero", 1, 0, "C");
    $pdf->Cell(20, 5, "Estado", 1, 0, "C");
    $pdf->Cell(40, 5, utf8_decode("Contraseña"), 1, 1, "C");
    

    $pdf->SetFont("Arial", "", 9);

    while ($fila = $result->fetch(PDO::FETCH_BOTH)) {
        $pdf->Cell(10, 5, $fila['user_id'], 1, 0, "C");
        $pdf->Cell(30, 5, utf8_decode($fila['username']), 1, 0, "C");
        $pdf->Cell(30, 5, utf8_decode($fila['first_name']), 1, 0, "C");
        $pdf->Cell(30, 5, utf8_decode($fila['last_name']), 1, 0, "C");
        $pdf->Cell(30, 5, $fila['gender'], 1, 0, "C");
        $pdf->Cell(20, 5, $fila['status'], 1, 0, "C");
        $pdf->Cell(40, 5, $fila['password'], 1, 1, "C");
    }

    $pdf->Output();
?>